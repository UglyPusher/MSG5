#include "BootstrapCli.h"

#include "PgExecutor.h"
#include "DbProbe.h"
#include "Utils/SqlUtil.h"
#include "Utils/Env.h"
#include "Config/ConfigLoader.h"

#include <nlohmann/json.hpp>

#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>

#ifdef _WIN32
#include <conio.h>
#else
#include <termios.h>
#include <unistd.h>
#endif

using nlohmann::json;
namespace fs = std::filesystem;
using msg5::utils::getenv_str;
using msg5::sql::quote_lit;

namespace {

    // -------------------------- ������� �����/������ --------------------------

    std::string prompt_line(const char* label, const std::string& def = {}) {
        std::string v;
        std::cout << label;
        if (!def.empty()) std::cout << " [" << def << "]";
        std::cout << ": ";
        std::getline(std::cin, v);
        if (v.empty()) v = def;
        return v;
    }

    std::string prompt_hidden(const char* label) {
        std::cout << label << ": ";
        std::string s;

#ifdef _WIN32
        for (;;) {
            int ch = _getch();
            if (ch == '\r' || ch == '\n') break;
            if (ch == 8 /*backspace*/) {
                if (!s.empty()) s.pop_back();
                continue;
            }
            if (ch == 3 /*Ctrl+C*/) { std::cout << "\n"; throw std::runtime_error("^C"); }
            if (ch >= 32 && ch <= 126) s.push_back(static_cast<char>(ch));
        }
        std::cout << "\n";
#else
        termios oldt{};
        tcgetattr(STDIN_FILENO, &oldt);
        termios newt = oldt;
        newt.c_lflag &= ~ECHO;
        tcsetattr(STDIN_FILENO, TCSANOW, &newt);
        std::getline(std::cin, s);
        tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
        std::cout << "\n";
#endif
        return s;
    }

    // ������ �������
    void print_usage() {
        std::cout <<
            R"(MSG5_Bootstrap � CLI

Usage:
  MSG5_Bootstrap validate
      [--dsn "..."] [--config PATH] [--stdin-json] [--ask-pass]

  MSG5_Bootstrap create-database
      [--bootstrap-dsn "..."] [--config PATH] [--stdin-json]
      [--dbname MSG5] [--owner msg5_app_owner] [--owner-pass ***|--ask-owner-pass]
      [--encoding UTF8] [--template template1]
      [--confirm CREATE-DB]

  MSG5_Bootstrap apply-meta-structure
      [--app-dsn "..."] [--baseline-dir PATH] [--config PATH] [--stdin-json]
      [--confirm APPLY-META]

Notes:
  - �������� ����������: CLI > STDIN-JSON > config (ENV MSG5_BOOTSTRAP_CONFIG ��������� ���� � �������).
  - �� ��������� create/apply �������� � DRY-RUN � ������ �������� ���� ([plan]).
    ��� ���������� �������� --confirm CREATE-DB / --confirm APPLY-META.
)";
    }

    // ������ JSON �� �����, ���� �� ����
    json load_config_json_if_any(const fs::path& config_path, bool& has_file_out) {
        has_file_out = false;
        if (config_path.empty()) return json::object();
        std::error_code ec;
        if (!fs::exists(config_path, ec)) return json::object();
        std::ifstream is(config_path, std::ios::binary);
        if (!is) return json::object();
        has_file_out = true;
        try {
            return json::parse(is);
        }
        catch (...) {
            return json::object();
        }
    }

    // ������ JSON �� stdin, ���� ���� �������
    json load_stdin_json_if_any(bool use_stdin) {
        if (!use_stdin) return json::object();
        std::istreambuf_iterator<char> it(std::cin.rdbuf());
        std::string buf(it, {});
        if (buf.empty()) return json::object();
        try { return json::parse(buf); }
        catch (...) { return json::object(); }
    }

    // -------------------------- ��������� ������� ���������� --------------------------

    struct Inputs {
        // validate
        std::string dsn;
        bool ask_pass = false;

        // create-database
        std::string bootstrap_dsn;
        std::string host, port;
        std::string dbname, owner, owner_pass;
        std::string encoding = "UTF8", templ = "template1";
        bool ask_owner_pass = false;

        // apply-meta-structure
        std::string app_dsn;
        fs::path baseline_dir;

        // infra
        bool stdin_json = false;
        fs::path config_path;
    };

    // -------------------------- ������� ���������� �� JSON --------------------------

    void merge_validate(const json& j, Inputs& in) {
        auto get = [&](const char* k, std::string& dst) {
            if (j.contains(k) && j.at(k).is_string() && dst.empty())
                dst = j.at(k).get<std::string>();
            };
        get("dsn", in.dsn);
        // ������������� � create-database: ����� ���������������� ����
        get("host", in.host);
        get("port", in.port);
        get("user", in.owner);      // �� �����������
        get("password", in.owner_pass);
    }

    void merge_create_db(const json& j, Inputs& in) {
        auto get = [&](const char* k, std::string& dst) {
            if (j.contains(k) && j.at(k).is_string() && dst.empty())
                dst = j.at(k).get<std::string>();
            };
        get("bootstrap_dsn", in.bootstrap_dsn);
        get("host", in.host);
        get("port", in.port);
        get("dbname", in.dbname);
        get("owner", in.owner);
        get("owner_pass", in.owner_pass);
        get("encoding", in.encoding);
        get("template", in.templ);
    }

    void merge_apply_meta(const json& j, Inputs& in) {
        auto get = [&](const char* k, std::string& dst) {
            if (j.contains(k) && j.at(k).is_string() && dst.empty())
                dst = j.at(k).get<std::string>();
            };
        get("app_dsn", in.app_dsn);
        if (j.contains("baseline_dir") && j.at("baseline_dir").is_string() && in.baseline_dir.empty())
            in.baseline_dir = j.at("baseline_dir").get<std::string>();
    }

    // -------------------------- ������ �� create-database --------------------------

    bool role_exists(PgExecutor& pg, const std::string& role) {
        auto v = pg.scalar("select exists(select 1 from pg_roles where rolname=" + quote_lit(role) + ")");
        return v == "t" || v == "true" || v == "1" || v == "TRUE";
    }

    bool database_exists_boot(PgExecutor& pg, const std::string& dbname) {
        auto v = pg.scalar("select exists(select 1 from pg_database where datname=" + quote_lit(dbname) + ")");
        return v == "t" || v == "true" || v == "1" || v == "TRUE";
    }

    // -------------------------- validate --------------------------

    int cmd_validate(Inputs in) {
        // resolve config path: CLI > ENV > default
        fs::path cfg = in.config_path;
        if (cfg.empty()) {
            if (auto e = getenv_str("MSG5_BOOTSTRAP_CONFIG")) {
                if (!e->empty()) cfg = *e;
            }
            else {
                cfg = fs::current_path() / "..\\..\\config\\bootstrap.json";
            }
        }

        bool has_file = false;
        json jfile = load_config_json_if_any(cfg, has_file);
        json jstdin = load_stdin_json_if_any(in.stdin_json);

        merge_validate(jfile, in);
        merge_validate(jstdin, in);

        if (in.dsn.empty()) {
            // ��������� ������� dsn ������������ (�������: host/port/dbname/user/password)
            std::cout << "[validate] DSN is empty � enter parts\n";
            in.host = in.host.empty() ? prompt_line("  host", "127.0.0.1") : in.host;
            in.port = in.port.empty() ? prompt_line("  port", "5432") : in.port;
            std::string db = prompt_line("  dbname", "postgres");
            std::string user = prompt_line("  user", "postgres");
            std::string pass = in.ask_pass ? prompt_hidden("  password") : std::string{};
            std::ostringstream os;
            os << "host=" << in.host << " port=" << in.port
                << " dbname=" << db << " user=" << user;
            if (!pass.empty()) os << " password=" << pass;
            in.dsn = os.str();
        }

        try {
            PgExecutor pg{ in.dsn.c_str() };
            auto ver = pg.scalar("select version()");
            auto ip = pg.scalar("select inet_server_addr()");
            auto pport = pg.scalar("select current_setting('port')");
            auto usr = pg.scalar("select current_user");
            std::cout << "[validate] ok\n"
                << "  version: " << ver << "\n"
                << "  server:  " << ip << ":" << pport << "\n"
                << "  user:    " << usr << "\n";
            return 0;
        }
        catch (const std::exception& e) {
            std::cerr << "[validate] ERROR: " << e.what() << "\n";
            return 7;
        }
    }

    // -------------------------- create-database --------------------------

    int cmd_create_database(Inputs in, const std::string& confirm) {
        // resolve config path: CLI > ENV > default
        fs::path cfg = in.config_path;
        if (cfg.empty()) {
            if (auto e = getenv_str("MSG5_BOOTSTRAP_CONFIG")) {
                if (!e->empty()) cfg = *e;
            }
            else {
                cfg = fs::current_path() / "..\\..\\config\\bootstrap.json";
            }
        }

        bool has_file = false;
        json jfile = load_config_json_if_any(cfg, has_file);
        json jstdin = load_stdin_json_if_any(in.stdin_json);

        merge_create_db(jfile, in);
        merge_create_db(jstdin, in);

        // ������� ������������� ��������������
        if (in.bootstrap_dsn.empty()) {
            std::cout << "[create] Enter bootstrap DSN (admin):\n";
            in.bootstrap_dsn = prompt_line("  bootstrap_dsn");
        }
        if (in.dbname.empty()) in.dbname = prompt_line("  dbname", "MSG5");
        if (in.owner.empty())  in.owner = prompt_line("  owner", "msg5_app_owner");
        if (in.ask_owner_pass && in.owner_pass.empty())
            in.owner_pass = prompt_hidden("  owner password");
        if (in.encoding.empty()) in.encoding = "UTF8";
        if (in.templ.empty())    in.templ = "template1";

        if (in.bootstrap_dsn.empty() || in.dbname.empty() || in.owner.empty()) {
            std::cerr << "ERROR: bootstrap_dsn/dbname/owner not specified\n";
            return 2;
        }

        const bool dry_run = (confirm != "CREATE-DB");

        try {
            PgExecutor boot{ in.bootstrap_dsn.c_str() };

            // ensure role
            if (!role_exists(boot, in.owner)) {
                std::ostringstream sql;
                sql << "CREATE ROLE " << in.owner << " LOGIN";
                if (!in.owner_pass.empty())
                    sql << " PASSWORD " << quote_lit(in.owner_pass);
                std::cout << (dry_run ? "[plan] " : "[do]   ")
                    << "create role " << in.owner << "\n";
                if (!dry_run) boot.exec(sql.str());
            }
            else {
                std::cout << "[plan] role " << in.owner << " already exists � skip\n";
            }

            // ensure database
            if (!database_exists_boot(boot, in.dbname)) {
                std::ostringstream sql;
                sql << "CREATE DATABASE " << in.dbname
                    << " OWNER " << in.owner
                    << " ENCODING " << quote_lit(in.encoding)
                    << " TEMPLATE " << in.templ;
                std::cout << (dry_run ? "[plan] " : "[do]   ")
                    << "create database " << in.dbname
                    << " owner " << in.owner
                    << " encoding " << in.encoding
                    << " template " << in.templ << "\n";
                if (!dry_run) boot.exec(sql.str());
            }
            else {
                std::cout << "[plan] database " << in.dbname << " already exists � skip\n";
            }

            if (dry_run) {
                std::cout << "\nDRY-RUN complete. To execute, add: --confirm CREATE-DB\n";
            }
            else {
                std::cout << "\nCREATE-DB done.\n";
            }
            return 0;
        }
        catch (const std::exception& e) {
            std::cerr << "ERROR: " << e.what() << "\n";
            return 7;
        }
    }

    // -------------------------- apply-meta-structure --------------------------

    std::vector<fs::path> list_sql_files(const fs::path& dir) {
        std::vector<fs::path> out;
        std::error_code ec;
        if (!fs::exists(dir, ec) || !fs::is_directory(dir, ec)) return out;
        for (auto& e : fs::directory_iterator(dir)) {
            if (!e.is_regular_file()) continue;
            auto p = e.path();
            auto ext = p.extension().string();
            std::transform(ext.begin(), ext.end(), ext.begin(),
                [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
            if (ext == ".sql") out.push_back(p);
        }
        std::sort(out.begin(), out.end());
        return out;
    }

    int cmd_apply_meta(Inputs in, const std::string& confirm) {
        // resolve config path: CLI > ENV > default
        fs::path cfg = in.config_path;
        if (cfg.empty()) {
            if (auto e = getenv_str("MSG5_BOOTSTRAP_CONFIG")) {
                if (!e->empty()) cfg = *e;
            }
            else {
                cfg = fs::current_path() / "..\\..\\config\\bootstrap.json";
            }
        }

        bool has_file = false;
        json jfile = load_config_json_if_any(cfg, has_file);
        json jstdin = load_stdin_json_if_any(in.stdin_json);

        merge_apply_meta(jfile, in);
        merge_apply_meta(jstdin, in);

        // ������������ ������ �����������
        if (in.app_dsn.empty()) {
            std::cout << "[apply] Enter app DSN (user that can create meta objects):\n";
            in.app_dsn = prompt_line("  app_dsn");
        }
        if (in.baseline_dir.empty())
            in.baseline_dir = prompt_line("  baseline_dir", ".\\db\\meta\\structure");

        if (in.app_dsn.empty() || in.baseline_dir.empty()) {
            std::cerr << "ERROR: app_dsn/baseline_dir not specified\n";
            return 2;
        }

        auto files = list_sql_files(in.baseline_dir);
        if (files.empty()) {
            std::cerr << "ERROR: no *.sql files found in " << in.baseline_dir.string() << "\n";
            return 2;
        }

        const bool dry_run = (confirm != "APPLY-META");

        try {
            PgExecutor app{ in.app_dsn.c_str() };

            // ���������������: ���� ���� ��� ���� � ������ �� ������
            if (msg5::dbprobe::meta_schema_present(app)) {
                std::cout << "[apply] meta.meta_schema already present � nothing to do\n";
                return 0;
            }

            std::cout << (dry_run ? "[plan] " : "[do]   ")
                << "Applying baseline from: " << in.baseline_dir.string() << "\n";

            for (auto& f : files) {
                std::cout << (dry_run ? "[plan] " : "[do]   ")
                    << "run " << f.filename().string() << "\n";
                if (dry_run) continue;

                std::ifstream is(f, std::ios::binary);
                if (!is) throw std::runtime_error("cannot open " + f.string());
                std::string sql((std::istreambuf_iterator<char>(is)), std::istreambuf_iterator<char>());
                if (!sql.empty()) app.exec(sql);
            }

            if (dry_run)
                std::cout << "\nDRY-RUN complete. To execute, add: --confirm APPLY-META\n";
            else
                std::cout << "\nAPPLY-META done.\n";

            return 0;
        }
        catch (const std::exception& e) {
            std::cerr << "ERROR: " << e.what() << "\n";
            return 7;
        }
    }

} // namespace

// -------------------------- ���� � CLI --------------------------

int RunBootstrapCli(int argc, char** argv) {
    if (argc < 2) { print_usage(); return 2; }
    std::string cmd = argv[1];

    Inputs in;
    std::string confirm;

    // ������� ������ ���������� (��� ��������� ���������)
    for (int i = 2; i < argc; ++i) {
        std::string a = argv[i];

        // �����
        if (a == "--stdin-json") { in.stdin_json = true; continue; }
        if (a == "--config" && i + 1 < argc) { in.config_path = argv[++i]; continue; }

        // validate
        if (a == "--dsn" && i + 1 < argc) { in.dsn = argv[++i]; continue; }
        if (a == "--ask-pass") { in.ask_pass = true; continue; }

        // create-database
        if (a == "--bootstrap-dsn" && i + 1 < argc) { in.bootstrap_dsn = argv[++i]; continue; }
        if (a == "--host" && i + 1 < argc) { in.host = argv[++i]; continue; }
        if (a == "--port" && i + 1 < argc) { in.port = argv[++i]; continue; }
        if (a == "--dbname" && i + 1 < argc) { in.dbname = argv[++i]; continue; }
        if (a == "--owner" && i + 1 < argc) { in.owner = argv[++i]; continue; }
        if (a == "--owner-pass" && i + 1 < argc) { in.owner_pass = argv[++i]; continue; }
        if (a == "--ask-owner-pass") { in.ask_owner_pass = true; continue; }
        if (a == "--encoding" && i + 1 < argc) { in.encoding = argv[++i]; continue; }
        if (a == "--template" && i + 1 < argc) { in.templ = argv[++i]; continue; }

        // apply-meta-structure
        if (a == "--app-dsn" && i + 1 < argc) { in.app_dsn = argv[++i]; continue; }
        if (a == "--baseline-dir" && i + 1 < argc) { in.baseline_dir = argv[++i]; continue; }

        // confirm
        if (a == "--confirm" && i + 1 < argc) { confirm = argv[++i]; continue; }

        // help
        if (a == "-h" || a == "--help" || a == "/?") { print_usage(); return 0; }

        std::cerr << "Unknown arg: " << a << "\n";
        return 2;
    }

    if (cmd == "validate")               return cmd_validate(in);
    if (cmd == "create-database")        return cmd_create_database(in, confirm);
    if (cmd == "apply-meta-structure")   return cmd_apply_meta(in, confirm);

    std::cerr << "Unknown command: " << cmd << "\n";
    print_usage();
    return 2;
}
